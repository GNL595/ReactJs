import React from 'react';
const person=(props)=>{
//return <h2>Functional Component</h2>

return(
<div>
{/* <h2>Functinal. I am {Math.random()*30}</h2> */}
<h2 onClick={props.clicked}>i am {props.name}. I am {props.age} years old</h2>
<p>{props.children}</p>
<input type="text" onChange={props.changed}value={props.name}></input>
</div>
)
}
export default person 