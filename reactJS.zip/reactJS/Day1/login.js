 export const login=(userName,password)=>{
     if(userName===password){
         console.log("sucessful");
    }
     else{
        console.log("unsucessful");
   }
}

let k; 
export default k = 12; 