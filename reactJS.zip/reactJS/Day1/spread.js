const numbers=[1,2,3]
console.log(numbers);
newNumbers=[...numbers,4]
console.log(newNumbers);

console.log(Math.max(newNumbers))//spread operator needed
console.log(Math.max(...newNumbers))



const person={
    name:'capg'
}
console.log(person);
const newPerson={
    ...person,location:'pune'
} 
console.log(newPerson);

function summArr(...arrSum){
    var result=0;
    for(let i=0;i<arrSum.length;i++){
        result+=arrSum[i]
    }
    return result
    
}
console.log(summArr(1,2,3))