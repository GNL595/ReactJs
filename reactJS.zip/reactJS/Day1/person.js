class Person{
    constructor(x){
        this.x=x;
    }
    showshit(){
        console.log(this.x);
    }
}
var person = new Person("have a shit day");
person.showshit();


class Human extends Person{
    
    constructor(){
        super('superrr da');
        this.gender='male'
        this.rate=1100
    }
    showgen(){
        console.log(this.gender)
        console.log(this.rate)
    }
}

const human = new Human;
human.showgen();
human.showshit();

