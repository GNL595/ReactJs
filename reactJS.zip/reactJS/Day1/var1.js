/*var x=10;
console.log(x)*/

var ho ="hello"
if(true){
ho="bubyee"
console.log(ho)
}
console.log(ho)



if(true){
    let he="bubyee"
console.log(he)
}
console.log(he  )



function show(){
 console.log(x);
 let x=10;
}
show()