//import login from './login'
//login('hi','hi')

//import m from './login'

// function sumNum(num1,num2){
//     return num1+num2;
// }
// console.log(sumNum(5,5));


// const SumNum=(num1,num2) => num1+num2;
// console.log(SumNum(5,-5));


// const sumNumm=()=>console.log("hi ravi")
// sumNumm();
// const sumNummm=msg=>console.log(msg)
// sumNummm("ravi bye");


// import k from './login'





let squares = [1,2,3].map(x=>x);
     [a, b] = squares;
     console.log(a+b);

