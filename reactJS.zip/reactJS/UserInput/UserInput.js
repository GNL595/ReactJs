import React from 'react';
const userInput=(props)=>{
    //return <h2>Functional Component</h2>
    
    return(
    <div>
    <h2 onClick={props.clicked}>I am {props.UserName}</h2>
    <input type="text" onChange={props.changed} value={props.name}></input>
    </div>
    )
    }
    export default userInput 