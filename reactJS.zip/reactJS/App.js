import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
//import Person from './Person/Person'
import UserInput from './UserInput/UserInput'
import UserOutput from './UserOutput/UserOutput'

class App extends Component {
  state={
    users:[
      {name:"ravi"},
      {name:"teja"},
      {name:"gnl"},
    ]
  }
  switchNameHandler=()=>{
    //console.log("clicked")
    //this.state.persons[o].name
    this.setState({
      users:[
      {name:"teja"},
      {name:"gnl"},
      {name:"ravi"},
      ]
    })
  }
  changeNameHandler=(event)=>{
    this.setState({
      users:[
        {name:"gnl"},
        {name:event.target.value},
        {name:"teja"},
      ]
    })
  }
render() {
  const style={
    backgroundcolour:'blue',
    font:'inherit',
    border:'ipx solid blue',
    padding:'20px',
    cursor:'pointer'
  }
return (
<div className="App">
<button onClick={()=>this.switchNameHandler.bind(this,"AEvent")}>switch</button>
<UserInput name={this.state.users[0].name} 
        clicked={this.switchNameHandler.bind(this,"AEvent")}
        changed={this.changeNameHandler}> 
</UserInput>
<UserOutput name={this.state.users[1].name} 
        clicked={this.switchNameHandler.bind(this,"AEvent")}>
</UserOutput>
<UserOutput name={this.state.users[1].name} />
</div>
/* {<header className="App-header">
<img src={logo} className="App-logo" alt="logo" />
<p>
Edit <code>src/App.js</code> and save to reload.
</p>
<a
className="App-link"
href="https://reactjs.org"
target="_blank"
rel="noopener noreferrer" }*/
/* >
Learn React
</a>
</header>
</div> */
);
}
}

export default App; 