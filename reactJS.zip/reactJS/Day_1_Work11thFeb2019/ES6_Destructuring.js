/* let hobbies=['Cooking','Reading','Sporting']
let [hobb1,hobb2]=hobbies;
console.log(hobb1+' '+hobb2) */

/* let person={
   Username:'Capgemini',
   Location:'Pune'
}
let {Username:un,Location:loc}=person
console.log(un+' '+loc) */
let val=100
let str=
`
Have a nice day
Hello ES6
ES6 ${val}

`
console.log(str)
