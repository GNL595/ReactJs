/* let numbers=[1,2,3,4];
newnumbers=[...numbers,6];
console.log(newnumbers) */

/* let numbers=[23,45,65,2,10,54];
console.log(Math.max(...numbers)) */

function sumArrar(...arrSum)
{
    var result=0;
    for(var i=0;i<arrSum.length;i++){
        result+=arrSum[i]
    }
    return result
}
console.log(sumArrar(12,34,45))

