/* function show(){
var x=10  //  Local variable 
//x=10    // Global variable 
console.log(x)
}
//x=10;
show();
console.log(x) */

/* const y="Hello ES6"
console.log(y);
y="Hello Good Morning"   //In case of const Reassignment of variable is not allow
console.log(y) */

/* var ab="Hello";
if(true)
{
    let ab="Hello React"  // Let works with block while var works with scope 
    console.log(ab)
}
console.log(ab) */

function show(){
    
    //x=10    
    console.log(x);
    let x=10 
    }

    show()