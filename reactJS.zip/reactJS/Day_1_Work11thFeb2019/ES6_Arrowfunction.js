/* function SumNum(num1,num2)
{
    return num1+num2;
} */

//const SumNum=(num1,num2)=>num1+num2;
//const SumNum=()=>console.log("Function with no parameter")
const SumNum=msg=>console.log(msg)
SumNum("Have a nice day")
 