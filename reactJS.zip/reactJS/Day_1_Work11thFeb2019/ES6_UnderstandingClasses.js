class Person
{
    //x="Hello Class"
    constructor(x)
    {
        this.x=x;
    }
    showinfo(){
        console.log(this.x)
    }


}
class Human extends Person{
    constructor(){
        super('Hello Super');
    this.gender='male'
    }
    showGen(){
    console.log(this.gender)
    }
}
const human=new Human;
human.showGen();
human.showinfo();

