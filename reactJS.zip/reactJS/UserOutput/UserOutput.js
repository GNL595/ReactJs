import React from 'react';
const userOutput=(props)=>{
    //    <h2 onClick={props.clicked}>i am {props.name}. I am {props.age} years old</h2>
    return(
    <div>
    <p>Hi {props.name}</p>
    <p>Hello {props.name}</p>
    </div>
    )
    }
    export default userOutput 