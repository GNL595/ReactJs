import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person'
class App extends Component {
  state={
    persons:[
      {name:"Acom",age:28},
      {name:"Bcom",age:32},
      {name:"Ccom",age:22}
    ],
    showPersons:false
  }
  switchNameHandler=(newName)=>{
    //console.log("Clicked!")
    //this.state.persons[0].name="React"
    this.setState({persons:[
      {name:newName,age:28},
      {name:"Bcom",age:32},
      {name:"Ccom",age:54}
    ]})
  }
  changeNameHandler=(event)=>{
    this.setState({persons:[
      {name:"Acom",age:28},
      {name:event.target.value,age:32},
      {name:"Ccom",age:54}
    ]})   
  }
  togglePersonHandler=()=>{
    const doesshow=this.state.showPersons
    this.setState({showPersons:!doesshow})
  }
  deletePersonHandler=(personIndex)=>{
     /*   //const persons=this.state.persons
       persons.splice(personIndex,1) */
       /* const persons=this.state.persons.slice(); */
       const persons=[...this.state.persons]
       persons.splice(personIndex,1)
       this.setState({persons:persons})
  }
  style={
    backgroundColor:'blue',
    font:'inherit',
    border:'ipx solid blue',
    padding:'10px',
    cursor:'pointer'
  } 
  render() {
    let persons=null;
    if(this.state.showPersons){
      persons=(
        <div>
        {this.state.persons.map((person,index)=>{
            return <Person name={person.name}
                           age={person.age}
                           click={()=>this.deletePersonHandler(index)}
                           changed={this.changeNameHandler}
                           />
        })}

</div>
      )
    }
       


        
        
    const style={
      backgroundColor:'blue',
      font:'inherit',
      border:'ipx solid blue',
      padding:'10px',
      cursor:'pointer'
    } 

    return (
      <div className="App">
          <button 
                 onClick={this.togglePersonHandler}
                 style={this.style}>Switch
          </button>
         
         {/* <Person name={this.state.persons[0].name} 
                 age={this.state.persons[0].age}>
         </Person>
         <Person name={this.state.persons[1].name} 
                 age={this.state.persons[1].age}
                 clicked={this.switchNameHandler.bind(this,"AEvenprop")}
                 changed={this.changeNameHandler}>I am children
          </Person>
         <Person name={this.state.persons[2].name} 
                 age={this.state.persons[2].age}>
         </Person> */}
         {persons}
              </div>
    )
  }
}

export default App;
